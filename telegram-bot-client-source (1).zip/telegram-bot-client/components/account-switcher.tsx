import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, Modal, Alert } from 'react-native';
import { useBotSession } from '@/lib/bot-context-v2';
import { useColors } from '@/hooks/use-colors';


export function AccountSwitcher() {
  const { state, switchAccount, removeAccount } = useBotSession();
  const colors = useColors();
  const [showMenu, setShowMenu] = useState(false);

  const currentAccount = state.accounts.find(a => a.id === state.currentAccountId);

  const handleRemoveAccount = (accountId: string) => {
    Alert.alert('Remove Account', 'Are you sure you want to remove this bot account?', [
      { text: 'Cancel', onPress: () => {} },
      {
        text: 'Remove',
        onPress: () => removeAccount(accountId),
        style: 'destructive',
      },
    ]);
  };

  const renderAccountItem = ({ item }: { item: any }) => {
    const isActive = item.id === state.currentAccountId;
    return (
      <TouchableOpacity
        onPress={() => {
          switchAccount(item.id);
          setShowMenu(false);
        }}
        className={`px-4 py-3 flex-row items-center justify-between border-b border-border ${
          isActive ? 'bg-primary/10' : ''
        }`}
      >
        <View className="flex-1">
          <Text className={`font-semibold ${isActive ? 'text-primary' : 'text-foreground'}`}>
            @{item.botUsername}
          </Text>
          <Text className="text-xs text-muted">{item.botName}</Text>
        </View>
        {isActive && <Text className="text-lg">✓</Text>}
      </TouchableOpacity>
    );
  };

  return (
    <>
      <TouchableOpacity
        onPress={() => setShowMenu(true)}
        className="flex-row items-center gap-2 px-3 py-2 rounded-lg bg-surface border border-border"
      >
        <View className="w-8 h-8 rounded-full bg-primary items-center justify-center">
          <Text className="text-sm font-bold text-background">
            {currentAccount?.botName.charAt(0).toUpperCase()}
          </Text>
        </View>
        <View className="flex-1">
          <Text className="text-xs text-muted">Bot</Text>
          <Text className="text-sm font-semibold text-foreground">
            @{currentAccount?.botUsername}
          </Text>
        </View>
        <Text className="text-lg">⋮</Text>
      </TouchableOpacity>

      <Modal
        visible={showMenu}
        transparent
        animationType="fade"
        onRequestClose={() => setShowMenu(false)}
      >
        
          <TouchableOpacity
            style={{ flex: 1 }}
            onPress={() => setShowMenu(false)}
            activeOpacity={1}
          >
            <View className="flex-1 justify-center items-center">
              <TouchableOpacity
                activeOpacity={1}
                onPress={(e) => e.stopPropagation()}
                className="bg-background rounded-2xl w-80 overflow-hidden"
              >
                <View className="px-4 py-4 border-b border-border">
                  <Text className="text-lg font-bold text-foreground">
                    Your Bot Accounts
                  </Text>
                </View>

                <FlatList
                  data={state.accounts}
                  renderItem={renderAccountItem}
                  keyExtractor={(item) => item.id}
                  scrollEnabled={state.accounts.length > 3}
                  maxToRenderPerBatch={5}
                />

                <TouchableOpacity
                  onPress={() => setShowMenu(false)}
                  className="px-4 py-3 border-t border-border items-center"
                >
                  <Text className="text-primary font-semibold">Close</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        
      </Modal>
    </>
  );
}
