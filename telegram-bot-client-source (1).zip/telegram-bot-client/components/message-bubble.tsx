import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useColors } from '@/hooks/use-colors';

interface MessageBubbleProps {
  text?: string;
  senderName: string;
  timestamp: number;
  isFromBot: boolean;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  photo?: string;
  replyTo?: {
    senderName: string;
    text: string;
  };
  edited?: boolean;
  onReply?: () => void;
}

const statusIcons = {
  sending: '⏱',
  sent: '✓',
  delivered: '✓✓',
  read: '✓✓',
};

export function MessageBubble({
  text,
  senderName,
  timestamp,
  isFromBot,
  status = 'sent',
  photo,
  replyTo,
  edited,
  onReply,
}: MessageBubbleProps) {
  const colors = useColors();
  const timeStr = new Date(timestamp * 1000).toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  // Color palette for different users
  const colorPalette = [
    { bubble: '#FF6B6B', text: '#FFFFFF' },
    { bubble: '#4ECDC4', text: '#FFFFFF' },
    { bubble: '#45B7D1', text: '#FFFFFF' },
    { bubble: '#96CEB4', text: '#FFFFFF' },
    { bubble: '#FFEAA7', text: '#2D3436' },
    { bubble: '#DDA15E', text: '#FFFFFF' },
  ];

  const userColorIndex = senderName.charCodeAt(0) % colorPalette.length;
  const userColor = colorPalette[userColorIndex];

  const bubbleStyle = isFromBot
    ? {
        backgroundColor: colors.primary,
        marginLeft: 'auto' as any,
        marginRight: 0,
      }
    : {
        backgroundColor: userColor.bubble,
        marginRight: 'auto' as any,
        marginLeft: 0,
      };

  const textColor = isFromBot ? colors.background : userColor.text;

  return (
    <TouchableOpacity
      onLongPress={onReply}
      activeOpacity={0.7}
      style={[styles.container, bubbleStyle] as any}
    >
      <View style={styles.content}>
        {/* Sender name for group chats */}
        {!isFromBot && (
          <Text style={[styles.senderName, { color: textColor, opacity: 0.8 }]}>
            {senderName}
          </Text>
        )}

        {/* Reply preview */}
        {replyTo && (
          <View style={[styles.replyPreview, { borderLeftColor: textColor, opacity: 0.7 }]}>
            <Text style={[styles.replyAuthor, { color: textColor }]}>
              {replyTo.senderName}
            </Text>
            <Text style={[styles.replyText, { color: textColor }]} numberOfLines={1}>
              {replyTo.text}
            </Text>
          </View>
        )}

        {/* Photo */}
        {photo && (
          <Image
            source={{ uri: photo }}
            style={styles.photo}
          />
        )}

        {/* Text message */}
        {text && (
          <Text style={[styles.text, { color: textColor }]}>
            {text}
          </Text>
        )}

        {/* Timestamp and status */}
        <View style={styles.footer}>
          <Text style={[styles.timestamp, { color: textColor, opacity: 0.7 }]}>
            {timeStr}
            {edited && ' (edited)'}
          </Text>
          {isFromBot && (
            <Text style={[styles.status, { color: textColor, opacity: 0.7, marginLeft: 4 }]}>
              {statusIcons[status]}
            </Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 4,
    marginHorizontal: 12,
    maxWidth: '85%',
    borderRadius: 18,
    overflow: 'hidden',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  content: {
    gap: 4,
  },
  senderName: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  replyPreview: {
    borderLeftWidth: 3,
    paddingLeft: 8,
    marginBottom: 4,
  },
  replyAuthor: {
    fontSize: 12,
    fontWeight: '600',
  },
  replyText: {
    fontSize: 12,
  },
  photo: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginVertical: 4,
  },
  text: {
    fontSize: 15,
    lineHeight: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 4,
  },
  timestamp: {
    fontSize: 12,
  },
  status: {
    fontSize: 12,
    fontWeight: '500',
  },
});
