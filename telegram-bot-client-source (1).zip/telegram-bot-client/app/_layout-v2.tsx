import { Stack } from 'expo-router';
import { ThemeProvider } from '@/lib/theme-provider';
import { BotProvider, useBotSession } from '@/lib/bot-context-v2';
import { useEffect, useState } from 'react';
import { useRouter } from 'expo-router';

function RootLayoutContent() {
  const { state, restoreState } = useBotSession();
  const router = useRouter();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        await restoreState();
        setIsReady(true);
      } catch (error) {
        console.error('Failed to restore state:', error);
        setIsReady(true);
      }
    };

    initializeApp();
  }, []);

  useEffect(() => {
    if (!isReady) return;

    if (state.isAuthenticated && state.accounts.length > 0) {
      router.replace('/(tabs)');
    } else {
      router.replace('/login-v2');
    }
  }, [state.isAuthenticated, state.accounts.length, isReady]);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="login-v2" />
      <Stack.Screen name="(tabs)" />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <ThemeProvider>
      <BotProvider>
        <RootLayoutContent />
      </BotProvider>
    </ThemeProvider>
  );
}
