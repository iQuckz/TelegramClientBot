import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBotSession } from '@/lib/bot-context-v2';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';

import * as Haptics from 'expo-haptics';

export default function LoginScreen() {
  const { state, addAccount } = useBotSession();
  const router = useRouter();
  const colors = useColors();
  const [token, setToken] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAddBot = async () => {
    if (!token.trim()) {
      Alert.alert('Error', 'Please enter a bot token');
      return;
    }

    try {
      setIsLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      await addAccount(token.trim());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setToken('');
      router.replace('/(tabs)');
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to add bot');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScreenContainer className="flex-1 bg-background">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
          <View className="flex-1 justify-center px-6 gap-8">
            {/* Header */}
            <View className="items-center gap-4">
              <Text className="text-6xl">🤖</Text>
              <View className="items-center gap-2">
                <Text className="text-3xl font-bold text-foreground">
                  Telegram Bot Client
                </Text>
                <Text className="text-sm text-muted text-center">
                  Control your Telegram bots with ease
                </Text>
              </View>
            </View>

            {/* Active Accounts */}
            {state.accounts.length > 0 && (
              
                <View className="p-4 gap-3">
                  <Text className="text-sm font-semibold text-foreground">
                    Active Accounts ({state.accounts.length})
                  </Text>
                  {state.accounts.map((account) => (
                    <View
                      key={account.id}
                      className="bg-surface/50 rounded-lg p-3 flex-row items-center gap-3"
                    >
                      <View className="w-10 h-10 rounded-full bg-primary items-center justify-center">
                        <Text className="text-sm font-bold text-background">
                          {account.botName.charAt(0).toUpperCase()}
                        </Text>
                      </View>
                      <View className="flex-1">
                        <Text className="font-semibold text-foreground">
                          @{account.botUsername}
                        </Text>
                        <Text className="text-xs text-muted">{account.botName}</Text>
                      </View>
                      <Text className="text-lg">✓</Text>
                    </View>
                  ))}
                </View>
              
            )}

            {/* Token Input Section */}
            
              <View className="p-6 gap-4">
                <View className="gap-2">
                  <Text className="text-sm font-semibold text-foreground">
                    Add New Bot Token
                  </Text>
                  <Text className="text-xs text-muted">
                    Get your token from @BotFather on Telegram
                  </Text>
                </View>

                <TextInput
                  value={token}
                  onChangeText={setToken}
                  placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                  placeholderTextColor={colors.muted}
                  editable={!isLoading}
                  multiline
                  maxLength={200}
                  className="bg-background border border-border rounded-lg px-4 py-3 text-foreground"
                  style={{ color: colors.foreground, minHeight: 80 }}
                />

                <Text className="text-xs text-muted">
                  🔒 Your token is stored securely on your device and never shared.
                </Text>
              </View>
            

            {/* Action Buttons */}
            <View className="gap-3">
              <TouchableOpacity
                onPress={handleAddBot}
                disabled={isLoading || !token.trim()}
                style={{ opacity: isLoading || !token.trim() ? 0.6 : 1 }}
                className="bg-primary rounded-lg py-4 items-center"
              >
                {isLoading ? (
                  <ActivityIndicator size="small" color={colors.background} />
                ) : (
                  <Text className="text-background font-bold text-base">
                    ✓ Connect Bot
                  </Text>
                )}
              </TouchableOpacity>

              {state.accounts.length > 0 && (
                <TouchableOpacity
                  onPress={() => router.replace('/(tabs)')}
                  className="bg-surface border border-border rounded-lg py-4 items-center"
                >
                  <Text className="text-foreground font-semibold">
                    Continue to Dashboard
                  </Text>
                </TouchableOpacity>
              )}
            </View>

            {/* Info Section */}
            <View className="gap-3 mt-auto">
              <View className="gap-2">
                <Text className="text-xs font-semibold text-foreground">
                  ℹ️ How to get your bot token:
                </Text>
                <Text className="text-xs text-muted leading-5">
                  1. Open Telegram and search for @BotFather{'\n'}
                  2. Send /newbot command{'\n'}
                  3. Follow the instructions{'\n'}
                  4. Copy your bot token and paste it here
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </ScreenContainer>
    </KeyboardAvoidingView>
  );
}
