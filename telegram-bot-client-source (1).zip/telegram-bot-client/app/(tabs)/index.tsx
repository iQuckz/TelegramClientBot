import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, ActivityIndicator, RefreshControl, Alert } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBotSession } from '@/lib/bot-context-v2';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';

import * as Haptics from 'expo-haptics';

interface BotStats {
  totalChats: number;
  pendingUpdates: number;
  lastUpdate: string | null;
}

export default function DashboardScreen() {
  const { state, logout } = useBotSession();
  const router = useRouter();
  const colors = useColors();
  const [stats, setStats] = useState<BotStats>({
    totalChats: 0,
    pendingUpdates: 0,
    lastUpdate: null,
  });
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const getCurrentToken = () => {
    if (!state.currentAccountId) return null;
    const account = state.accounts.find(a => a.id === state.currentAccountId);
    return account?.token || null;
  };

  const getCurrentAccount = () => {
    if (!state.currentAccountId) return null;
    return state.accounts.find(a => a.id === state.currentAccountId);
  };

  const fetchStats = async () => {
    const token = getCurrentToken();
    if (!token) return;

    try {
      setIsLoading(true);
      const response = await fetch(
        `https://api.telegram.org/bot${token}/getUpdates?limit=1`,
        { method: 'GET' }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.ok) {
          const updates = data.result || [];
          setStats({
            totalChats: updates.length > 0 ? updates.length : 0,
            pendingUpdates: updates.length,
            lastUpdate: new Date().toLocaleTimeString(),
          });
        }
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [state.currentAccountId]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchStats();
    setIsRefreshing(false);
  };

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', onPress: () => {} },
      {
        text: 'Logout',
        onPress: async () => {
          try {
            await logout();
            router.replace('/login');
          } catch (error) {
            Alert.alert('Error', 'Failed to logout');
          }
        },
        style: 'destructive',
      },
    ]);
  };

  const currentAccount = getCurrentAccount();

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}
      >
        <View className="flex-1 px-4 py-6 gap-6">
          {/* Header with Bot Info */}
          
            <View className="p-6 gap-4">
              <View className="flex-row items-center gap-4">
                <View className="w-16 h-16 rounded-full bg-primary items-center justify-center">
                  <Text className="text-3xl font-bold text-background">
                    {currentAccount?.botName.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <View className="flex-1">
                  <Text className="text-xl font-bold text-foreground">
                    {currentAccount?.botName}
                  </Text>
                  <Text className="text-sm text-muted">
                    @{currentAccount?.botUsername}
                  </Text>
                  <Text className="text-xs text-muted/50 mt-1">
                    ID: {currentAccount?.botId}
                  </Text>
                </View>
              </View>
            </View>
          

          {/* Stats Cards */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground px-2">Statistics</Text>
            <View className="flex-row gap-3">
              
                <View className="p-4 items-center gap-2">
                  <Text className="text-2xl">💬</Text>
                  <Text className="text-2xl font-bold text-foreground">
                    {isLoading ? <ActivityIndicator /> : stats.totalChats}
                  </Text>
                  <Text className="text-xs text-muted text-center">Total Chats</Text>
                </View>
              

              
                <View className="p-4 items-center gap-2">
                  <Text className="text-2xl">📬</Text>
                  <Text className="text-2xl font-bold text-foreground">
                    {isLoading ? <ActivityIndicator /> : stats.pendingUpdates}
                  </Text>
                  <Text className="text-xs text-muted text-center">Updates</Text>
                </View>
              
            </View>
          </View>

          {/* Last Update */}
          {stats.lastUpdate && (
            
              <View className="px-4 py-3">
                <Text className="text-xs text-muted">Last Updated</Text>
                <Text className="text-sm font-semibold text-foreground mt-1">
                  {stats.lastUpdate}
                </Text>
              </View>
            
          )}

          {/* Action Buttons */}
          <View className="gap-3 mt-auto">
            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.navigate('/(tabs)/chats');
              }}
              className="bg-primary rounded-lg py-4 items-center"
            >
              <Text className="text-background font-bold">💬 View Chats</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.navigate('/(tabs)/send-message');
              }}
              className="bg-primary rounded-lg py-4 items-center"
            >
              <Text className="text-background font-bold">✉️ Send Message</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.navigate('/(tabs)/updates');
              }}
              className="bg-surface border border-border rounded-lg py-4 items-center"
            >
              <Text className="text-foreground font-semibold">⚙️ Updates & Webhook</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleLogout}
              className="bg-error/10 border border-error rounded-lg py-4 items-center"
            >
              <Text className="text-error font-semibold">🚪 Logout</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
