import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBotSession } from '@/lib/bot-context-v2';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';
import { MessageBubble } from '@/components/message-bubble';
import * as Haptics from 'expo-haptics';
// import * as ImagePicker from 'expo-image-picker';


interface Message {
  id: string;
  text: string;
  date: number;
  from_bot: boolean;
  senderName: string;
  photo?: string;
  replyTo?: {
    senderName: string;
    text: string;
  };
}

export default function ChatDetailScreenV2() {
  const { state, dispatch } = useBotSession();
  const { chatId } = useLocalSearchParams();
  const router = useRouter();
  const colors = useColors();
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [chatInfo, setChatInfo] = useState<any>(null);
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    fetchMessages();
    fetchChatInfo();
  }, [chatId, state.currentAccountId]);

  const getCurrentToken = () => {
    if (!state.currentAccountId) return null;
    const account = state.accounts.find(a => a.id === state.currentAccountId);
    return account?.token || null;
  };

  const fetchChatInfo = async () => {
    const token = getCurrentToken();
    if (!token || !chatId) return;

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/getChat?chat_id=${chatId}`);
      const data = await response.json();
      if (data.ok) {
        setChatInfo(data.result);
      }
    } catch (error) {
      console.error('Failed to fetch chat info:', error);
    }
  };

  const fetchMessages = async () => {
    const token = getCurrentToken();
    if (!token || !chatId) return;

    try {
      setIsLoading(true);
      const response = await fetch(
        `https://api.telegram.org/bot${token}/getUpdates?limit=50`,
        { method: 'GET' }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.result) {
          const updates = data.result;
          const chatMessages: Message[] = [];

          updates.forEach((update: any) => {
            if (update.message?.chat?.id === parseInt(chatId as string)) {
              chatMessages.push({
                id: `${update.update_id}`,
                text: update.message.text || '[Non-text message]',
                date: update.message.date,
                from_bot: false,
                senderName: update.message.from?.first_name || 'Unknown',
                photo: update.message.photo?.[0]?.file_id,
              });
            }
          });

          setMessages(chatMessages.reverse());
        }
      }
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!messageText.trim()) return;

    const token = getCurrentToken();
    if (!token) return;

    try {
      setIsSending(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      const payload: any = {
        chat_id: chatId,
        text: messageText,
      };

      if (replyingTo) {
        payload.reply_to_message_id = parseInt(replyingTo.id);
      }

      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.ok) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setMessageText('');
        setReplyingTo(null);
        await fetchMessages();
        flatListRef.current?.scrollToEnd();
      } else {
        Alert.alert('Error', data.description || 'Failed to send message');
      }
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to send message');
    } finally {
      setIsSending(false);
    }
  };

  const handlePickImage = async () => {
    Alert.alert('Coming Soon', 'Photo sending will be available in the next update');
  };

  const renderMessage = ({ item }: { item: Message }) => (
    <MessageBubble
      text={item.text}
      senderName={item.senderName}
      timestamp={item.date}
      isFromBot={item.from_bot}
      photo={item.photo}
      replyTo={item.replyTo}
      onReply={() => setReplyingTo(item)}
    />
  );

  const renderDateSeparator = (date: number) => (
    <View style={{ alignItems: 'center', marginVertical: 16 }}>
      <Text style={{ color: colors.muted, fontSize: 12 }}>
        {new Date(date * 1000).toLocaleDateString()}
      </Text>
    </View>
  );

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
      keyboardVerticalOffset={90}
    >
      <ScreenContainer className="flex-1 bg-background">
        {/* Header */}
        
          <View className="px-4 py-4 flex-row items-center gap-3 border-b border-border">
            <TouchableOpacity onPress={() => router.back()}>
              <Text className="text-2xl">←</Text>
            </TouchableOpacity>
            <View className="flex-1">
              <Text className="text-lg font-bold text-foreground">
                {chatInfo?.title || `Chat ${chatId}`}
              </Text>
              {chatInfo?.type === 'group' && (
                <Text className="text-xs text-muted">
                  {chatInfo?.members_count || 0} members
                </Text>
              )}
            </View>
            <TouchableOpacity>
              <Text className="text-2xl">⋮</Text>
            </TouchableOpacity>
          </View>
        

        {/* Messages List */}
        {isLoading ? (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator size="large" color={colors.primary} />
          </View>
        ) : messages.length === 0 ? (
          <View className="flex-1 items-center justify-center gap-2">
            <Text className="text-5xl">💬</Text>
            <Text className="text-sm text-muted">No messages yet</Text>
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            renderItem={renderMessage}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingVertical: 12 }}
            inverted
            onEndReachedThreshold={0.5}
          />
        )}

        {/* Reply Preview */}
        {replyingTo && (
          
            <View className="bg-surface rounded-lg p-3 flex-row items-center justify-between border border-border">
              <View className="flex-1">
                <Text className="text-xs text-muted font-semibold">
                  Replying to {replyingTo.senderName}
                </Text>
                <Text className="text-sm text-foreground" numberOfLines={1}>
                  {replyingTo.text}
                </Text>
              </View>
              <TouchableOpacity onPress={() => setReplyingTo(null)}>
                <Text className="text-lg">✕</Text>
              </TouchableOpacity>
            </View>
          
        )}

        {/* Message Input */}
        
          <View className="flex-row gap-2 items-end">
            <TouchableOpacity
              onPress={handlePickImage}
              className="bg-primary/20 rounded-full w-10 h-10 items-center justify-center"
            >
              <Text className="text-lg">📎</Text>
            </TouchableOpacity>

            <TextInput
              value={messageText}
              onChangeText={setMessageText}
              placeholder="Message..."
              placeholderTextColor={colors.muted}
              editable={!isSending}
              multiline
              maxLength={4096}
              className="flex-1 bg-surface border border-border rounded-2xl px-4 py-3 text-foreground"
              style={{ color: colors.foreground, maxHeight: 100 }}
            />

            <TouchableOpacity
              onPress={handleSendMessage}
              disabled={!messageText.trim() || isSending}
              style={{ opacity: !messageText.trim() || isSending ? 0.5 : 1 }}
              className="bg-primary rounded-full w-10 h-10 items-center justify-center"
            >
              {isSending ? (
                <ActivityIndicator size="small" color={colors.background} />
              ) : (
                <Text className="text-lg">✈️</Text>
              )}
            </TouchableOpacity>
          </View>
        
      </ScreenContainer>
    </KeyboardAvoidingView>
  );
}
