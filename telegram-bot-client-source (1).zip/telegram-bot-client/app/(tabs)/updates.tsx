import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Switch,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBotSession } from '@/lib/bot-context-v2';
import { useColors } from '@/hooks/use-colors';

import * as Haptics from 'expo-haptics';

export default function UpdatesScreen() {
  const { state } = useBotSession();
  const colors = useColors();
  const [updateMode, setUpdateMode] = useState<'polling' | 'webhook'>('polling');
  const [webhookUrl, setWebhookUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [webhookInfo, setWebhookInfo] = useState<any>(null);
  const [pollingInterval, setPollingInterval] = useState('2');

  const getCurrentToken = () => {
    if (!state.currentAccountId) return null;
    const account = state.accounts.find(a => a.id === state.currentAccountId);
    return account?.token || null;
  };

  useEffect(() => {
    fetchWebhookInfo();
  }, [state.currentAccountId]);

  const fetchWebhookInfo = async () => {
    const token = getCurrentToken();
    if (!token) return;

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/getWebhookInfo`, {
        method: 'GET',
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok) {
          setWebhookInfo(data.result);
          if (data.result.url) {
            setUpdateMode('webhook');
            setWebhookUrl(data.result.url);
          }
        }
      }
    } catch (error) {
      console.error('Failed to fetch webhook info:', error);
    }
  };

  const handleSetWebhook = async () => {
    if (!webhookUrl.trim()) {
      Alert.alert('Error', 'Please enter a webhook URL');
      return;
    }

    const token = getCurrentToken();
    if (!token) return;

    try {
      setIsLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      const response = await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: webhookUrl,
        }),
      });

      const data = await response.json();

      if (data.ok) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Success', 'Webhook set successfully!');
        await fetchWebhookInfo();
      } else {
        Alert.alert('Error', data.description || 'Failed to set webhook');
      }
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to set webhook');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteWebhook = async () => {
    const token = getCurrentToken();
    if (!token) return;

    try {
      setIsLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      const response = await fetch(`https://api.telegram.org/bot${token}/deleteWebhook`, {
        method: 'POST',
      });

      const data = await response.json();

      if (data.ok) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Success', 'Webhook deleted!');
        setUpdateMode('polling');
        setWebhookUrl('');
        await fetchWebhookInfo();
      } else {
        Alert.alert('Error', data.description || 'Failed to delete webhook');
      }
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to delete webhook');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-6 gap-6">
          {/* Header */}
          <View className="items-center gap-2">
            <Text className="text-4xl">⚙️</Text>
            <Text className="text-2xl font-bold text-foreground">Updates & Webhook</Text>
            <Text className="text-sm text-muted text-center">
              Configure how your bot receives updates
            </Text>
          </View>

          {/* Update Mode Selection */}
          
            <View className="p-4 gap-4">
              <Text className="text-sm font-semibold text-foreground">Update Mode</Text>

              {/* Polling Option */}
              <TouchableOpacity
                onPress={() => setUpdateMode('polling')}
                className={`p-4 rounded-lg border ${
                  updateMode === 'polling'
                    ? 'bg-primary/20 border-primary'
                    : 'bg-surface border-border'
                }`}
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-1">
                    <Text
                      className={`font-semibold ${
                        updateMode === 'polling' ? 'text-primary' : 'text-foreground'
                      }`}
                    >
                      📡 Polling
                    </Text>
                    <Text className="text-xs text-muted mt-1">
                      Bot regularly checks for new messages
                    </Text>
                  </View>
                  {updateMode === 'polling' && <Text className="text-lg">✓</Text>}
                </View>
              </TouchableOpacity>

              {/* Webhook Option */}
              <TouchableOpacity
                onPress={() => setUpdateMode('webhook')}
                className={`p-4 rounded-lg border ${
                  updateMode === 'webhook'
                    ? 'bg-primary/20 border-primary'
                    : 'bg-surface border-border'
                }`}
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-1">
                    <Text
                      className={`font-semibold ${
                        updateMode === 'webhook' ? 'text-primary' : 'text-foreground'
                      }`}
                    >
                      🔗 Webhook
                    </Text>
                    <Text className="text-xs text-muted mt-1">
                      Telegram sends updates to your server
                    </Text>
                  </View>
                  {updateMode === 'webhook' && <Text className="text-lg">✓</Text>}
                </View>
              </TouchableOpacity>
            </View>
          

          {/* Webhook Configuration */}
          {updateMode === 'webhook' && (
            
              <View className="p-4 gap-3">
                <Text className="text-sm font-semibold text-foreground">Webhook URL</Text>
                <TextInput
                  value={webhookUrl}
                  onChangeText={setWebhookUrl}
                  placeholder="https://example.com/webhook"
                  placeholderTextColor={colors.muted}
                  editable={!isLoading}
                  className="bg-background border border-border rounded-lg px-4 py-3 text-foreground"
                  style={{ color: colors.foreground }}
                />

                <TouchableOpacity
                  onPress={handleSetWebhook}
                  disabled={isLoading || !webhookUrl.trim()}
                  style={{ opacity: isLoading || !webhookUrl.trim() ? 0.6 : 1 }}
                  className="bg-primary rounded-lg py-3 items-center mt-2"
                >
                  {isLoading ? (
                    <ActivityIndicator size="small" color={colors.background} />
                  ) : (
                    <Text className="text-background font-semibold">Set Webhook</Text>
                  )}
                </TouchableOpacity>

                {webhookInfo?.url && (
                  <TouchableOpacity
                    onPress={handleDeleteWebhook}
                    disabled={isLoading}
                    className="bg-error/10 border border-error rounded-lg py-3 items-center"
                  >
                    <Text className="text-error font-semibold">Delete Webhook</Text>
                  </TouchableOpacity>
                )}
              </View>
            
          )}

          {/* Polling Configuration */}
          {updateMode === 'polling' && (
            
              <View className="p-4 gap-3">
                <Text className="text-sm font-semibold text-foreground">Polling Interval</Text>
                <Text className="text-xs text-muted">
                  How often the bot checks for new messages (in seconds)
                </Text>
                <TextInput
                  value={pollingInterval}
                  onChangeText={setPollingInterval}
                  placeholder="2"
                  placeholderTextColor={colors.muted}
                  keyboardType="number-pad"
                  className="bg-background border border-border rounded-lg px-4 py-3 text-foreground"
                  style={{ color: colors.foreground }}
                />
              </View>
            
          )}

          {/* Current Status */}
          {webhookInfo && (
            
              <View className="p-4 gap-2">
                <Text className="text-sm font-semibold text-foreground">Current Status</Text>
                {webhookInfo.url ? (
                  <>
                    <Text className="text-xs text-muted">Webhook URL:</Text>
                    <Text className="text-xs text-foreground font-mono">{webhookInfo.url}</Text>
                  </>
                ) : (
                  <Text className="text-xs text-muted">No webhook configured (using polling)</Text>
                )}
              </View>
            
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
