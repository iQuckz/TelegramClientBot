import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBotSession } from '@/lib/bot-context-v2';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';


interface Chat {
  id: number;
  type: string;
  title?: string;
  first_name?: string;
  username?: string;
}

interface ChatUpdate {
  update_id: number;
  message?: {
    chat: Chat;
    text?: string;
    date: number;
  };
}

export default function ChatsScreen() {
  const { state } = useBotSession();
  const router = useRouter();
  const colors = useColors();
  const [chats, setChats] = useState<Chat[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const getCurrentToken = () => {
    if (!state.currentAccountId) return null;
    const account = state.accounts.find(a => a.id === state.currentAccountId);
    return account?.token || null;
  };

  const fetchChats = async () => {
    const token = getCurrentToken();
    if (!token) return;

    try {
      setIsLoading(true);
      const response = await fetch(
        `https://api.telegram.org/bot${token}/getUpdates?limit=100`,
        { method: 'GET' }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.result) {
          const updates: ChatUpdate[] = data.result;
          const uniqueChats = new Map<number, Chat>();

          updates.forEach((update) => {
            if (update.message?.chat) {
              const chat = update.message.chat;
              if (!uniqueChats.has(chat.id)) {
                uniqueChats.set(chat.id, chat);
              }
            }
          });

          setChats(Array.from(uniqueChats.values()));
        }
      }
    } catch (error) {
      console.error('Failed to fetch chats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchChats();
  }, [state.currentAccountId]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchChats();
    setIsRefreshing(false);
  };

  const getChatName = (chat: Chat) => {
    if (chat.type === 'private') {
      return chat.first_name || `Chat ${chat.id}`;
    }
    return chat.title || `Chat ${chat.id}`;
  };

  const renderChatItem = ({ item }: { item: Chat }) => (
    <TouchableOpacity
      onPress={() => router.navigate({ pathname: '/(tabs)/chat-detail', params: { chatId: item.id } })}
      className="mx-4 mb-3"
    >
      
        <View className="bg-surface/50 rounded-lg p-4 flex-row items-center justify-between border border-border">
          <View className="flex-1 gap-1">
            <Text className="text-base font-semibold text-foreground">{getChatName(item)}</Text>
            <Text className="text-xs text-muted">
              {item.type === 'private' ? '👤 Private Chat' : '👥 ' + item.type}
            </Text>
          </View>
          <Text className="text-lg">→</Text>
        </View>
      
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="flex-1 bg-background">
      {isLoading && chats.length === 0 ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : chats.length === 0 ? (
        <View className="flex-1 items-center justify-center gap-2">
          <Text className="text-5xl">💬</Text>
          <Text className="text-sm text-muted">No chats yet</Text>
        </View>
      ) : (
        <FlatList
          data={chats}
          renderItem={renderChatItem}
          keyExtractor={(item) => `${item.id}`}
          contentContainerStyle={{ paddingVertical: 12 }}
          refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={handleRefresh} />}
        />
      )}
    </ScreenContainer>
  );
}
