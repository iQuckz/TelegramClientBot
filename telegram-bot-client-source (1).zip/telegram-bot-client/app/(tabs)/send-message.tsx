import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useBotSession } from '@/lib/bot-context-v2';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';

import * as Haptics from 'expo-haptics';

export default function SendMessageScreen() {
  const { state } = useBotSession();
  const router = useRouter();
  const colors = useColors();
  const [chatId, setChatId] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [parseMode, setParseMode] = useState<'HTML' | 'Markdown' | 'MarkdownV2'>('HTML');

  const getCurrentToken = () => {
    if (!state.currentAccountId) return null;
    const account = state.accounts.find(a => a.id === state.currentAccountId);
    return account?.token || null;
  };

  const handleSendMessage = async () => {
    if (!chatId.trim() || !message.trim()) {
      Alert.alert('Error', 'Please enter both chat ID and message');
      return;
    }

    const token = getCurrentToken();
    if (!token) {
      Alert.alert('Error', 'No bot token found');
      return;
    }

    try {
      setIsLoading(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: parseMode,
        }),
      });

      const data = await response.json();

      if (data.ok) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        Alert.alert('Success', 'Message sent!');
        setChatId('');
        setMessage('');
      } else {
        Alert.alert('Error', data.description || 'Failed to send message');
      }
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to send message');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="flex-1 bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 justify-center px-6 gap-6">
          {/* Header */}
          <View className="items-center gap-2">
            <Text className="text-4xl">✉️</Text>
            <Text className="text-2xl font-bold text-foreground">Send Message</Text>
            <Text className="text-sm text-muted text-center">
              Send a message to any chat using your bot
            </Text>
          </View>

          {/* Chat ID Input */}
          
            <View className="p-4 gap-2">
              <Text className="text-sm font-semibold text-foreground">Chat ID</Text>
              <TextInput
                value={chatId}
                onChangeText={setChatId}
                placeholder="Enter chat ID or username"
                placeholderTextColor={colors.muted}
                editable={!isLoading}
                keyboardType="number-pad"
                className="bg-background border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground }}
              />
              <Text className="text-xs text-muted">
                You can find the chat ID in the chat details or use the username with @
              </Text>
            </View>
          

          {/* Message Input */}
          
            <View className="p-4 gap-2">
              <Text className="text-sm font-semibold text-foreground">Message</Text>
              <TextInput
                value={message}
                onChangeText={setMessage}
                placeholder="Type your message here..."
                placeholderTextColor={colors.muted}
                editable={!isLoading}
                multiline
                maxLength={4096}
                className="bg-background border border-border rounded-lg px-4 py-3 text-foreground"
                style={{ color: colors.foreground, minHeight: 120 }}
              />
            </View>
          

          {/* Parse Mode Selection */}
          
            <View className="p-4 gap-3">
              <Text className="text-sm font-semibold text-foreground">Text Format</Text>
              <View className="gap-2">
                {(['HTML', 'Markdown', 'MarkdownV2'] as const).map((mode) => (
                  <TouchableOpacity
                    key={mode}
                    onPress={() => setParseMode(mode)}
                    className={`p-3 rounded-lg border ${
                      parseMode === mode
                        ? 'bg-primary/20 border-primary'
                        : 'bg-surface border-border'
                    }`}
                  >
                    <Text
                      className={`font-semibold ${
                        parseMode === mode ? 'text-primary' : 'text-foreground'
                      }`}
                    >
                      {mode}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          

          {/* Send Button */}
          <TouchableOpacity
            onPress={handleSendMessage}
            disabled={isLoading || !chatId.trim() || !message.trim()}
            style={{ opacity: isLoading || !chatId.trim() || !message.trim() ? 0.6 : 1 }}
            className="bg-primary rounded-lg py-4 items-center mt-auto mb-4"
          >
            {isLoading ? (
              <ActivityIndicator size="small" color={colors.background} />
            ) : (
              <Text className="text-background font-bold text-base">✈️ Send Message</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
