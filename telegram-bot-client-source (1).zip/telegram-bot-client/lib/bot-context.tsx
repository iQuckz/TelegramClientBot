import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import * as SecureStore from 'expo-secure-store';

export interface BotInfo {
  id: number;
  is_bot: boolean;
  first_name: string;
  username?: string;
  can_join_groups?: boolean;
  can_read_all_group_messages?: boolean;
  supports_inline_queries?: boolean;
  can_connect_to_business?: boolean;
}

export interface BotSession {
  token: string;
  botInfo: BotInfo | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

type BotAction =
  | { type: 'SET_TOKEN'; payload: string }
  | { type: 'SET_BOT_INFO'; payload: BotInfo }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'LOGOUT' }
  | { type: 'RESTORE_SESSION'; payload: { token: string; botInfo: BotInfo } };

const initialState: BotSession = {
  token: '',
  botInfo: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
};

function botReducer(state: BotSession, action: BotAction): BotSession {
  switch (action.type) {
    case 'SET_TOKEN':
      return { ...state, token: action.payload };
    case 'SET_BOT_INFO':
      return { ...state, botInfo: action.payload, isAuthenticated: true };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'LOGOUT':
      return initialState;
    case 'RESTORE_SESSION':
      return {
        ...state,
        token: action.payload.token,
        botInfo: action.payload.botInfo,
        isAuthenticated: true,
      };
    default:
      return state;
  }
}

interface BotContextType {
  state: BotSession;
  loginBot: (token: string) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const BotContext = createContext<BotContextType | undefined>(undefined);

export function BotProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(botReducer, initialState);

  // Restore session on app load
  useEffect(() => {
    const restoreSession = async () => {
      try {
        const savedToken = await SecureStore.getItemAsync('bot_token');
        const savedBotInfo = await SecureStore.getItemAsync('bot_info');

        if (savedToken && savedBotInfo) {
          dispatch({
            type: 'RESTORE_SESSION',
            payload: {
              token: savedToken,
              botInfo: JSON.parse(savedBotInfo),
            },
          });
        }
      } catch (error) {
        console.error('Failed to restore session:', error);
      }
    };

    restoreSession();
  }, []);

  const loginBot = async (token: string) => {
    dispatch({ type: 'SET_LOADING', payload: true });
    dispatch({ type: 'SET_ERROR', payload: null });

    try {
      // Validate token by calling getMe
      const response = await fetch(`https://api.telegram.org/bot${token}/getMe`, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Invalid bot token');
      }

      const data = await response.json();

      if (!data.ok) {
        throw new Error(data.description || 'Failed to authenticate bot');
      }

      const botInfo: BotInfo = data.result;

      // Save token and bot info securely
      await SecureStore.setItemAsync('bot_token', token);
      await SecureStore.setItemAsync('bot_info', JSON.stringify(botInfo));

      dispatch({ type: 'SET_TOKEN', payload: token });
      dispatch({ type: 'SET_BOT_INFO', payload: botInfo });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Authentication failed';
      dispatch({ type: 'SET_ERROR', payload: errorMessage });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const logout = async () => {
    try {
      await SecureStore.deleteItemAsync('bot_token');
      await SecureStore.deleteItemAsync('bot_info');
      dispatch({ type: 'LOGOUT' });
    } catch (error) {
      console.error('Failed to logout:', error);
    }
  };

  const clearError = () => {
    dispatch({ type: 'SET_ERROR', payload: null });
  };

  return (
    <BotContext.Provider value={{ state, loginBot, logout, clearError }}>
      {children}
    </BotContext.Provider>
  );
}

export function useBotSession() {
  const context = useContext(BotContext);
  if (context === undefined) {
    throw new Error('useBotSession must be used within BotProvider');
  }
  return context;
}
