import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import * as SecureStore from 'expo-secure-store';

export interface BotAccount {
  id: string;
  token: string;
  botName: string;
  botUsername: string;
  botId: number;
  createdAt: number;
}

export interface Message {
  id: number;
  chatId: number;
  text?: string;
  caption?: string;
  photo?: string;
  document?: string;
  voice?: string;
  video?: string;
  replyToMessageId?: number;
  replyToMessage?: Message;
  senderName: string;
  senderId: number;
  timestamp: number;
  isFromBot: boolean;
  status: 'sending' | 'sent' | 'delivered' | 'read';
  edited: boolean;
  editedAt?: number;
}

export interface Chat {
  id: number;
  title: string;
  type: 'private' | 'group' | 'supergroup' | 'channel';
  lastMessage?: Message;
  lastMessageTime?: number;
  unreadCount: number;
  photo?: string;
  members?: number;
  description?: string;
}

export interface BotState {
  currentAccountId: string | null;
  accounts: BotAccount[];
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  chats: Chat[];
  messages: { [chatId: number]: Message[] };
  selectedChatId: number | null;
}

type BotAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'ADD_ACCOUNT'; payload: BotAccount }
  | { type: 'REMOVE_ACCOUNT'; payload: string }
  | { type: 'SET_CURRENT_ACCOUNT'; payload: string }
  | { type: 'SET_AUTHENTICATED'; payload: boolean }
  | { type: 'SET_CHATS'; payload: Chat[] }
  | { type: 'ADD_MESSAGE'; payload: { chatId: number; message: Message } }
  | { type: 'UPDATE_MESSAGE'; payload: { chatId: number; messageId: number; updates: Partial<Message> } }
  | { type: 'DELETE_MESSAGE'; payload: { chatId: number; messageId: number } }
  | { type: 'SET_MESSAGES'; payload: { chatId: number; messages: Message[] } }
  | { type: 'SET_SELECTED_CHAT'; payload: number | null }
  | { type: 'RESTORE_STATE'; payload: BotState };

const initialState: BotState = {
  currentAccountId: null,
  accounts: [],
  isAuthenticated: false,
  isLoading: false,
  error: null,
  chats: [],
  messages: {},
  selectedChatId: null,
};

function botReducer(state: BotState, action: BotAction): BotState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'ADD_ACCOUNT':
      return {
        ...state,
        accounts: [...state.accounts, action.payload],
        currentAccountId: action.payload.id,
      };
    case 'REMOVE_ACCOUNT':
      return {
        ...state,
        accounts: state.accounts.filter(a => a.id !== action.payload),
        currentAccountId: state.currentAccountId === action.payload ? null : state.currentAccountId,
      };
    case 'SET_CURRENT_ACCOUNT':
      return { ...state, currentAccountId: action.payload };
    case 'SET_AUTHENTICATED':
      return { ...state, isAuthenticated: action.payload };
    case 'SET_CHATS':
      return { ...state, chats: action.payload };
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: [
            ...(state.messages[action.payload.chatId] || []),
            action.payload.message,
          ],
        },
      };
    case 'UPDATE_MESSAGE':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: (state.messages[action.payload.chatId] || []).map(m =>
            m.id === action.payload.messageId ? { ...m, ...action.payload.updates } : m
          ),
        },
      };
    case 'DELETE_MESSAGE':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: (state.messages[action.payload.chatId] || []).filter(
            m => m.id !== action.payload.messageId
          ),
        },
      };
    case 'SET_MESSAGES':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: action.payload.messages,
        },
      };
    case 'SET_SELECTED_CHAT':
      return { ...state, selectedChatId: action.payload };
    case 'RESTORE_STATE':
      return action.payload;
    default:
      return state;
  }
}

interface BotContextType {
  state: BotState;
  dispatch: React.Dispatch<BotAction>;
  addAccount: (token: string) => Promise<void>;
  removeAccount: (accountId: string) => Promise<void>;
  switchAccount: (accountId: string) => void;
  logout: () => Promise<void>;
  getCurrentToken: () => string | null;
  saveState: () => Promise<void>;
  restoreState: () => Promise<void>;
}

const BotContext = createContext<BotContextType | undefined>(undefined);

export function BotProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(botReducer, initialState);

  const getCurrentToken = () => {
    if (!state.currentAccountId) return null;
    const account = state.accounts.find(a => a.id === state.currentAccountId);
    return account?.token || null;
  };

  const addAccount = async (token: string) => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const response = await fetch(`https://api.telegram.org/bot${token}/getMe`);
      const data = await response.json();

      if (!data.ok) {
        throw new Error(data.description || 'Invalid token');
      }

      const botData = data.result;
      const accountId = `bot_${botData.id}_${Date.now()}`;
      const account: BotAccount = {
        id: accountId,
        token,
        botName: botData.first_name,
        botUsername: botData.username,
        botId: botData.id,
        createdAt: Date.now(),
      };

      dispatch({ type: 'ADD_ACCOUNT', payload: account });
      dispatch({ type: 'SET_AUTHENTICATED', payload: true });
      
      await SecureStore.setItemAsync('bot_accounts', JSON.stringify([...state.accounts, account]));
      await SecureStore.setItemAsync('current_account_id', accountId);
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: error instanceof Error ? error.message : 'Failed to add account' });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const removeAccount = async (accountId: string) => {
    try {
      dispatch({ type: 'REMOVE_ACCOUNT', payload: accountId });
      const updatedAccounts = state.accounts.filter(a => a.id !== accountId);
      await SecureStore.setItemAsync('bot_accounts', JSON.stringify(updatedAccounts));
      
      if (state.currentAccountId === accountId && updatedAccounts.length > 0) {
        switchAccount(updatedAccounts[0].id);
      }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Failed to remove account' });
    }
  };

  const switchAccount = (accountId: string) => {
    dispatch({ type: 'SET_CURRENT_ACCOUNT', payload: accountId });
    SecureStore.setItemAsync('current_account_id', accountId);
  };

  const logout = async () => {
    try {
      if (state.currentAccountId) {
        await removeAccount(state.currentAccountId);
      }
      if (state.accounts.length === 0) {
        dispatch({ type: 'SET_AUTHENTICATED', payload: false });
        await SecureStore.deleteItemAsync('bot_accounts');
        await SecureStore.deleteItemAsync('current_account_id');
      }
    } catch (error) {
      dispatch({ type: 'SET_ERROR', payload: 'Failed to logout' });
    }
  };

  const saveState = async () => {
    try {
      await SecureStore.setItemAsync('bot_state', JSON.stringify(state));
    } catch (error) {
      console.error('Failed to save state:', error);
    }
  };

  const restoreState = async () => {
    try {
      const savedState = await SecureStore.getItemAsync('bot_state');
      if (savedState) {
        const parsedState = JSON.parse(savedState);
        dispatch({ type: 'RESTORE_STATE', payload: parsedState });
      }

      const accountsStr = await SecureStore.getItemAsync('bot_accounts');
      if (accountsStr) {
        const accounts = JSON.parse(accountsStr);
        accounts.forEach((account: BotAccount) => {
          dispatch({ type: 'ADD_ACCOUNT', payload: account });
        });
      }

      const currentAccountId = await SecureStore.getItemAsync('current_account_id');
      if (currentAccountId) {
        dispatch({ type: 'SET_CURRENT_ACCOUNT', payload: currentAccountId });
        dispatch({ type: 'SET_AUTHENTICATED', payload: true });
      }
    } catch (error) {
      console.error('Failed to restore state:', error);
    }
  };

  useEffect(() => {
    restoreState();
  }, []);

  useEffect(() => {
    saveState();
  }, [state]);

  const value: BotContextType = {
    state,
    dispatch,
    addAccount,
    removeAccount,
    switchAccount,
    logout,
    getCurrentToken,
    saveState,
    restoreState,
  };

  return <BotContext.Provider value={value}>{children}</BotContext.Provider>;
}

export function useBotSession() {
  const context = useContext(BotContext);
  if (!context) {
    throw new Error('useBotSession must be used within BotProvider');
  }
  return context;
}
